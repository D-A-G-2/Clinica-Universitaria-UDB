/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package loginmysql;

/**
 *
 * @author IVAN-PC
 */


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class LoginMySQL {

    public static void main(String[] args) {

        String usuario = JOptionPane.showInputDialog(
                null,
                "Ingrese el usuario:"
        );

        String clave = JOptionPane.showInputDialog(
                null,
                "Ingrese la contraseña:"
        );

        try {

            // Crear objeto de la clase Conexion
            Conexion con = new Conexion(); /// CON MYSQL
               
            // Obtener la conexión
            Connection cn = con.conectar();

            String sql = "SELECT * FROM usuarios "
                    + "WHERE usuario=? AND clave=?";

            PreparedStatement ps =
                    cn.prepareStatement(sql);

            ps.setString(1, usuario);
            ps.setString(2, clave);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                JOptionPane.showMessageDialog(
                        null,
                        "Bienvenido " + usuario
                );

            } else {

                JOptionPane.showMessageDialog(
                        null,
                        "Usuario o contraseña incorrectos"
                );
            }

            cn.close();

        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    null,
                    e.getMessage()
            );
        }
    }
}