/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginmysql;

/**
 *
 * @author IVAN-PC
 */

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {

    Connection conectar = null;

    public Connection conectar() {

        try {

            Class.forName(
              "com.mysql.cj.jdbc.Driver"
            );

            conectar =
                    DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/empresa",
                    "root",
                    ""
                    );

        } catch (Exception e) {

            System.out.println(
                    "Error: "
                            + e.getMessage()
            );
        }

        return conectar;
    }
    
    
    
    
}

